DB_CLUSTER = ""
DB_NAME = "postgres"
MASTER_USERNAME = "postgres"
MASTER_PASSWORD = ""
ARN = "arn:aws:rds:us-east-2:500514381816:cluster:postgres"
SECRET_ARN = "arn:aws:secretsmanager:us-east-2:500514381816:secret:rds-db-credentials/cluster-33FXTTBJUA6VTIJBXQWHEGXQRE/postgres-3QyWu7"

#errors:
ERR = None
STATUS_CODE = "200"
RES = "Success"