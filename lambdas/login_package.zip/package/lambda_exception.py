class LambdaException(Exception):
    pass